<?php
include('verifica_login.php');
include('conexao.php');
?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Guardar registo</title>

  <!-- Favicon -->
  <link href="template/img/favicon.ico" rel="icon">

<!-- Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Lato&family=Oswald:wght@200;300;400&display=swap" rel="stylesheet">

<!-- CSS Libraries -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
<link href="lib/animate/animate.min.css" rel="stylesheet">
<link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<!-- Template Stylesheet -->
<link href="template/css/style.css" rel="stylesheet">  
</head>
<body>
<?php
  $nome = mysqli_real_escape_string($conexao, $_POST['nome']);
  $email = mysqli_real_escape_string($conexao, $_POST['email']);
  $palavrapasse = mysqli_real_escape_string($conexao, $_POST['palavrapasse']);
  
  $query = "insert into login (nome, email, palavrapasse) values ('{$nome}', '{$email}', {$palavrapasse})";
  $conexao = mysqli_connect('localhost', 'root', '', 'lavandaria');
  if(mysqli_query($conexao, $query)) {
  ?>
      <div class="container">
    <div class="row">
        <div class="col-8">
            <div class="card">
             <div class="card-header">
            </div>
            <div class="card-body">
              <div class="alert alert-success" role="alert">
                Conta criada com sucesso!
              </div>
              <a href="index.php" class="btn btn-primary">Voltar ao login</a>
            </div>
            </div>      
            </div>           
            </div>             
        </div>
    </div>
  <?php
  } else {
  ?>
      <p class="alert-danger">
          ERRO - O registo não foi adicionado!
      </p>
  <?php
  }
  ?>
</body>
</html>