<?php
include('verifica_login.php');
include('conexao.php');
?>
<!DOCTYPE html>
<html lang="pt">
    <head>
        <meta charset="utf-8">
        <title>Lista de Pedidos</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="Consulting Website Template Free Download" name="keywords">
        <meta content="Consulting Website Template Free Download" name="description">

        <!-- Favicon -->
        <link href="template/img/favicon.ico" rel="icon">

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css2?family=Lato&family=Oswald:wght@200;300;400&display=swap" rel="stylesheet">
        
        <!-- CSS Libraries -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
        
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

        <!-- Template Stylesheet -->
        <link href="template/css/style.css" rel="stylesheet">
    </head>
<body>

<div class="top-bar d-none d-md-block">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                        <div class="top-bar-left">
                            <div class="text">
                                <i class="far fa-clock"></i>
                                <h2>9:00-13:00 15:00-19:00</h2>
                                <p>Segunda - Sexta </p>
                                <h2>9:00-13:00</h2>
                                <p>Sabado</p>
                            </div>
                            <div class="text">
                                <i class="fa fa-phone-alt"></i>
                                <h2>263042951 ou 912221545</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="top-bar-right">
                            <div class="social">
                                <a href="https://www.facebook.com/fatiotalimpa.engomadorialavandaria"><i class="fab fa-facebook-f"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <img class="logo" src="img/logo.jpg" width="150px" height="100px">
        
        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                </div>
        <div class="container">
      <div class="row">
          <div class="col-8">
                <div class="card">
            <div class="card-body">
                <h5 class="card-title">Lista das Pedidos</h5>
                <table class="table table-sm">
                <thead>
                    <tr>
                    <th scope="col">Nome</th>
                    <th scope="col">Data</th>
                    <th scope="col">CodPostal</th>
                    <th scope="col">NIF</th>
                    <th scope="col">Localidade</th>
                    <th scope="col">Telemovel/Telefone</th>
                    <th scope="col">Quantidade</th>
                    <th scope="col">Tipo de roupa</th>
                    <th scope="col">Tipo de serviço</th>
                    </tr>
                </thead>
                
                
                <tbody>
                     <tr>
        <?php
$conexao = mysqli_connect('localhost', 'root', '', 'lavandaria');

// seleciona a base de dados em que vamos trabalhar
// cria a instrução SQL que vai selecionar os dados
$query = "SELECT nomecliente, data, codpostal, nif, localidade, telemoveloutelefone,quantidade, idservico, idtiporoupa FROM clientes;";


$dados = (mysqli_query($conexao, $query));
// transforma os dados em um array
$linha = mysqli_fetch_assoc($dados);
// calcula quantos dados retornaram
$total = mysqli_num_rows($dados);
	// se o número de resultados for maior que zero, mostra os dados
	if($total > 0) {
		// inicia o loop que vai mostrar todos os dados
		do {

			
		
?>

        
                      <th scope="row"><?php echo $linha['nomecliente']?></th>
                      <td><?php echo $linha['data']; ?></td>
                      <td><?php echo $linha['codpostal']; ?></td>
                      <td><?php echo $linha['nif']; ?></td>
                      <td><?php echo $linha['localidade']; ?></td>
                      <td><?php echo $linha['telemoveloutelefone']; ?></td>
                      <td><?php echo $linha['quantidade']; ?></td>
                      <?php
                      $query1 = "SELECT desginacao FROM tiposroupa WHERE idtiporoupa=".$linha['idtiporoupa'].";";
                      $dados1 = mysqli_query($conexao, $query1);
                      $linha1 = mysqli_fetch_assoc($dados1);
                      $query2 = "SELECT nomeservico FROM tiposervico WHERE idservico=".$linha['idservico'].";";
                      $dados2 = mysqli_query($conexao, $query2);
                      $linha2 = mysqli_fetch_assoc($dados2);
                      ?>
                      <td><?php echo $linha1['desginacao']; ?></td>
                      <td><?php echo $linha2['nomeservico']; ?></td>
                     </tr>
                     
                     <?php
                //finaliza o loop que vai mostrar os dados
		}while($linha = mysqli_fetch_assoc($dados));
	// fim do if
	}
    ?>
    
                </tbody>
                </table>
                </div>
                </div>
                        
                <?php
// tira o resultado da busca da memória
mysqli_free_result($dados);
?>   
                            
                </div>
                </div>
                <a href="painel.php" class="btn btn-primary">Menu dos pedidos</a>
            </div>
            
</body>
</html>