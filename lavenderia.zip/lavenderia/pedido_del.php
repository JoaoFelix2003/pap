<?php
include('verifica_login.php');
include('conexao.php');
?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Eliminar pedido</title>

  <!-- Favicon -->
  <link href="template/img/favicon.ico" rel="icon">

<!-- Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Lato&family=Oswald:wght@200;300;400&display=swap" rel="stylesheet">

<!-- CSS Libraries -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
<link href="lib/animate/animate.min.css" rel="stylesheet">
<link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<!-- Template Stylesheet -->
<link href="template/css/style.css" rel="stylesheet">
</head>
<body>
<div class="top-bar d-none d-md-block">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                        <div class="top-bar-left">
                            <div class="text">
                                <i class="far fa-clock"></i>
                                <h2>9:00-13:00 15:00-19:00</h2>
                                <p>Segunda - Sexta </p>
                                <h2>9:00-13:00</h2>
                                <p>Sabado</p>
                            </div>
                            <div class="text">
                                <i class="fa fa-phone-alt"></i>
                                <h2>263042951 ou 912221545</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="top-bar-right">
                            <div class="social">
                                <a href="https://www.facebook.com/fatiotalimpa.engomadorialavandaria"><i class="fab fa-facebook-f"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <img class="logo" src="img/logo.jpg" width="150px" height="100px">

<?php
  $nome = mysqli_real_escape_string($conexao, $_POST['nome']);
  $data = mysqli_real_escape_string($conexao, $_POST['data']);
  $codpostal = mysqli_real_escape_string($conexao, $_POST['codpostal']);
  $nif = mysqli_real_escape_string($conexao, $_POST['nif']);
  $localidade = mysqli_real_escape_string($conexao, $_POST['localidade']);
  $telemoveloutelefone = mysqli_real_escape_string($conexao, $_POST['telemoveloutelefone']);
  $quantidade = mysqli_real_escape_string($conexao, $_POST['quantidade']);
  $roupa = mysqli_real_escape_string($conexao, $_POST['roupa']);
  $servico = mysqli_real_escape_string($conexao, $_POST['servico']);
  
  
  $query = "DELETE clientes (nomecliente, data, codpostal, nif, localidade, telemoveloutelefone,quantidade, idservico, idtiporoupa) values ('{$nome}', '{$data}', '{$codpostal}', {$nif}, '{$localidade}', {$telemoveloutelefone},{$quantidade}, {$servico}, {$roupa})";
  $conexao = mysqli_connect('localhost', 'root', '', 'lavandaria');
  if(mysqli_query($conexao, $query)) {
  ?>
      <div class="container">
    <div class="row">
        <div class="col-8">
            <div class="card">
             <div class="card-header">
              Gestão de Pedido | Eliminação
            </div>
            <div class="card-body">
              <div class="alert alert-success" role="alert">
                Pedido Eliminado com sucesso!
              </div>
              <a href="pedido_list.php" class="btn btn-primary">Lista de Pedidos</a>
            </div>
                        
                        
                            
        </div>
    </div>
</div>
  <?php
  } else {
  ?>
      <p class="alert-danger">
          ERRO - O registo não foi adicionado!
          <?php echo $query ?>
      </p>
  <?php
  }
  ?>
</body>
</html>