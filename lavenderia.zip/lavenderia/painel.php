<?php
include('verifica_login.php');
include('conexao.php');
?>
<!DOCTYPE html>
<html lang="pt">
    <head>
        <meta charset="utf-8">
        <title>Fazer pedido</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="Consulting Website Template Free Download" name="keywords">
        <meta content="Consulting Website Template Free Download" name="description">

        <!-- Favicon -->
        <link href="template/img/favicon.ico" rel="icon">

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css2?family=Lato&family=Oswald:wght@200;300;400&display=swap" rel="stylesheet">
        
        <!-- CSS Libraries -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
        
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

        <!-- Template Stylesheet -->
        <link href="template/css/style.css" rel="stylesheet">
    </head>
<body>

<div class="top-bar d-none d-md-block">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                        <div class="top-bar-left">
                            <div class="text">
                                <i class="far fa-clock"></i>
                                <h2>9:00-13:00 15:00-19:00</h2>
                                <p>Segunda - Sexta </p>
                                <h2>9:00-13:00</h2>
                                <p>Sabado</p>
                            </div>
                            <div class="text">
                                <i class="fa fa-phone-alt"></i>
                                <h2>263042951 ou 912221545</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="top-bar-right">
                            <div class="social">
                                <a href="https://www.facebook.com/fatiotalimpa.engomadorialavandaria"><i class="fab fa-facebook-f"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="navbar navbar-expand-lg bg-dark navbar-dark">
            <div class="container-fluid">
                <img class="logo" src="img/logo.jpg" width="150px" height="100px">
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                    <div class="navbar-nav ml-auto">
                        <a href="pedido_list.php" class="nav-item nav-link">Os meus pedidos</a>
                        <a href="logout.php" class="nav-item nav-link">Logout</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Carousel Start -->
        <div class="carousel">
            <div class="container-fluid">
                <div class="owl-carousel">
                    <div class="carousel-item">
                        <div class="carousel-img">
                            <img src="img/intro.jpg" alt="Image">
                        </div>
                        <div class="carousel-text">
      
                      <h1>Fazer pedido</h1>
                      
      <form></form>
      <form action="guardapedido.php" method="POST">
      
      <label for="fname" style="color: white;">Nome</label>
      <input type="text" id="name" name="nome" class="form-control" required>

      <label for="fname" style="color: white;">Data</label>
      <input type="date" id="data" name="data" required><br><br>

      
      <label for="fname" style="color: white;">Codigo-Postal</label>
      <input type="int" id="codpostal" name="codpostal" maxlength="8" required><br><br>

      
      <label for="fname" style="color: white;">Identificação Fiscal</label>
      <input type="int" id="nif" name="nif" maxlength="9" required><br><br>

      
      <label for="fname" style="color: white;">Localidade</label>
      <input type="text" id="localidade" name="localidade" required><br><br>

      
      <label for="fname" style="color: white;">Telemóvel/Telefone</label>
      <input type="int" id="telemoveloutelefone" name="telemoveloutelefone" maxlength="9" required>
                        
      
                          

      <?php
$res = mysqli_query($conexao,"SELECT idservico, nomeservico, descricao FROM tiposervico")or die (mysqli_error()); /*Executa o comando SQL, no caso para pegar todos os usuarios do sistema e retorna o valor da consulta em uma variavel ($res)  */


?>



  <label style="color: white;">Selecione um Serviço</label>

  <select id="servico" name="servico" required>

    <option>Selecione...</option>

     



    <?php while($escrever=mysqli_fetch_array($res)){ ?>

    <option value="<?php echo $escrever['idservico'] ?>"><?php echo $escrever['nomeservico'] ?></option>

    <?php } ?>

  </select>

  <?php
$res1 = mysqli_query($conexao,"SELECT idtiporoupa, desginacao FROM tiposroupa")or die (mysqli_error()); /*Executa o comando SQL, no caso para pegar todos os usuarios do sistema e retorna o valor da consulta em uma variavel ($res)  */


?>



  <label style="color: white;">Selecione um tipo de roupa</label>

  <select id="roupa" name="roupa" required>

    <option>Selecione...</option>

     



    <?php while($escrever1=mysqli_fetch_array($res1)){ ?>

    <option value="<?php echo $escrever1['idtiporoupa'] ?>"><?php echo utf8_encode( $escrever1['desginacao'] )?></option>

    <?php } ?>

  </select>

  <label for="fname" style="color: white;">Quantidade</label>
  <input type="number" id="quantidade" name="quantidade" required>
  <button type="submit" class="btn btn-primary">Registar Pedido</button>

  
  

                     
  
    
                    </div>
                </div>
            </div>
        </div>
      </div>
      
      </form>
</body>

</html>
